#' deartifact_peaks
#'
#' @description Annotate a vector of qsessions with
#' in-source sphingolipid lipid artifacts (dehydrations, multimerization,
#' deglycosylations, etc.) and isotopes.
#' A "Retention Time" or "Retention.Time" column must be present to work.
#'
#' @usage
#' deartifact_peaks(
#'     filenames,
#'     category,
#'     Q1_tolerance,
#'     retention_tolerance,
#'     ...)
#'
#' @param filenames Vector of peak files.
#' @param category LIPID MAPS 2-letter string denoting the lipid category.
#' Currently supports "SP" or "GP".
#' @param Q1_tolerance m/z tolerance of mass spectrometer. '0.5' means +/- 0.5
#' m/z units above and below the target m/z.
#' @param retention_tolerance Number of significant digits to match peaks by
#' shared retention time. 2 is the default.
#' @param ... Advanced parameter to customize the 'annotation_table'.
#'
#' @format \tabular{lll}{
#' filenames \tab \tab Character string/vector. \cr
#' category \tab \tab 2-character string. \cr
#' Q1_tolerance \tab \tab Numeric. \cr
#' retention_tolerance \tab \tab Integer. \cr
#' ... 3 column data.table named "Delta_q1", "Insource_annotation", and "Type".
#' Delta_q1 is the parent ion m/z of the annotation from Insource_annotation.
#' Type is an integer used to compute all compound annotations. Compound
#' annotations are only generated from annotations with unique integer Types.}
#'
#' @return
#' List of output files with an additional column "Insource_annotation"
#' indicating any in-source artifacts/isotopes.
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export deartifact_peaks
#'

deartifact_peaks <- function(
    filenames, category, Q1_tolerance, retention_tolerance, ...) {

    ## Error-checking
    if (missing(category)) {
        stop(paste0(
            "Must specify a 2-letter LIPID MAPS code denoting the category. ",
            "Currently supports 'SP' for sphingolipids and 'GP' for ",
            "glycerophospholipids."))
    }
    if (!(category %in% c("SP", "GP"))) {
        stop(paste0(
            "Category must be 'SP' for sphingolipids or ",
            "'GP' for glycerophospholipids."))
    }
    if (missing(Q1_tolerance)) {
        stop("Must specify a Q1_tolerance value")
    }
    if (!(is.numeric(Q1_tolerance))) {
        stop("Q1_tolerance must be numeric.")
    }
    if (missing(retention_tolerance)) {
        retention_tolerance <- 2
    }
    if (!(retention_tolerance %% 1 == 0) | retention_tolerance < 0) {
        stop("retention_tolerance must be a whole number.")
    }

    ## Capture unevaluated expression about the annotation table
    params <- list(...)
    if ("annotation_table" %in% names(params)) {
        anno_dt <- params[[which(names(params) %in% "annotation_table")]]
    } else {
        anno_dt <- deartifact_peaks_anno_table(category = category)
    }

    ## Check for the first 4-5 mandatory columns in the peak files
    mandatory_cols <- c(
        "Index", "Sample.Index", "Sample.Name", "Mass.Info")
    for (kFile in seq_along(filenames)) {
        loaded <- nb_label_peaks_load(filename = filenames[kFile])
        colnames(loaded) <- gsub("\\s+", ".", colnames(loaded))
        check_vec <- mandatory_cols %in% colnames(loaded)
        if (any(check_vec == FALSE)) {
            stop(paste0(
                "The following column(s) are missing in the peak files:\n",
                paste0(mandatory_cols[check_vec == FALSE], collapse = ", ")))
        }
    }

    output <- vector("list", length = length(filenames))

    for (kFile in seq_along(output)) {
        output[[kFile]] <- deartifact_peaks_deartifact(
            filename = filenames[kFile],
            anno_dt = anno_dt,
            category = category,
            Q1_tolerance = Q1_tolerance,
            retention_tolerance = retention_tolerance)
    }

    return(output)
}
