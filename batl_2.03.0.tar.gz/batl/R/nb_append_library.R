#' nb_append_library
#'
#' @description Reshape and concatenate peak files to the training library.
#'
#' @usage
#' nb_append_library(
#'     library,
#'     labelled_files,
#'     filenames,
#'     qstandard,
#'     qstandard_col,
#'     subtract_constant,
#'     barcode_decision,
#'     detected_col,
#'     ...)
#'
#' @param library Labelled peak list library.
#' @param labelled_files List of labelled peak files.
#' @param filenames Vector of peak file names (to create the Filename column).
#' @param qstandard Internal standard for feature normalization.
#' @param qstandard_col Column name where the internal standard is indicated.
#' @param subtract_constant Constant for subtracted retention time feature
#' @param barcode_decision Barcode_<decision_rule> column from BATL
#' @param detected_col Feature column to check if the peak was detected or not.
#' @param ... Advanced argument to specify which features should be normalized
#' to the internal standard. Default setting normalizes "Area", "Height",
#' "Relative.RT", and "Subtracted.RT" using the internal standard.
#'
#' @details
#' \tabular{lll}{
#' library \tab \tab Data.table. \cr
#' labelled_files \tab \tab List of data.tables. \cr
#' filenames \tab \tab Character vector. \cr
#' qstandard \tab \tab String. \cr
#' qstandard_col \tab \tab String. \cr
#' subtract_constant \tab \tab Numeric. \cr
#' barcode_decision \tab \tab String. \cr
#' detected_col \tab \tab String. \cr
#' ... \tab \tab 2 column matrix with column names "Feature" and "Normalize".\cr
#' \tab \tab 1st column contains the feature names. 2nd column TRUE/FALSE. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_append_library

nb_append_library <- function(
    library, labelled_files, filenames, qstandard, qstandard_col,
    subtract_constant, barcode_decision, detected_col, ...) {

    ## Null strategy to pass R CMD check
    Mass.Info <- Q1 <- Q3 <- Detected <- NULL

    ## Capture unevaluated expression about which features get normalized to the
    ## internal standard qstandard
    params <- list(...)
    if ("feature_norm" %in% names(params)) {
        feature_norm <- params[[which(names(params) %in% "feature_norm")]]
        if (!(is.matrix(feature_norm))) {
            stop("feature_norm must be an n x 2 matrix.")
        }
        if (ncol(feature_norm) != 2) {
            stop("feature_norm must be an n x 2 matrix.")
        }
        if (!(is.character(feature_norm[, 1]))) {
            stop("The first column must contain features (character type).")
        }
        if (!(all(feature_norm[, 2] %in% c("TRUE", "FALSE", "T", "F")))) {
            stop(paste0(
                "The second column must be TRUE/FALSE/T/F ",
                "(coerced as character type)."))
        }
        feature_norm[, 1] <- gsub("\\s+", ".", feature_norm[, 1])
        colnames(feature_norm) <- c("Feature", "Normalize")
    } else {
        feature_norm <- matrix(c(
            "Retention.Time", FALSE,
            "Area", TRUE,
            "Height", TRUE,
            "Width.at.50%", FALSE,
            "Tailing.Factor", FALSE,
            "Asymmetry.Factor", FALSE,
            "Relative.RT", TRUE,
            "Subtracted.RT", TRUE),
            ncol = 2,
            byrow = TRUE,
            dimnames = list(c(), c("Feature", "Normalize")))
    }
    fnorm_vector <- feature_norm[feature_norm[, "Normalize"] == T, "Feature"]

    ## Get all columns of the library
    lib_cols <- colnames(library)

    ## Error-checking
    if (missing(detected_col)) {
        stop("Must specify detected_col.")
    }
    detected_col <- gsub("\\s+", ".", detected_col)
    if (!("Barcode" %in% lib_cols)) {
        stop("The column 'Barcode' is missing from the library.")
    }
    if (!("Filename" %in% lib_cols)) {
        stop("The column 'Filename' is missing from the library.")
    }
    lib_cols <- lib_cols[!(lib_cols %in% c("Filename", "Barcode"))]
    if (missing(filenames)) {
        stop(paste0(
            "Must specify filenames corresponding to the names of ",
            "each file in labelled_files."))
    }
    if (missing(labelled_files)) {
        stop("labelled_files must be specified.")
    }
    if (!(is.list(labelled_files))) {
        stop("labelled_files must be a list.")
    }
    if (length(filenames) != length(labelled_files)) {
        stop(paste0(
            "Must specify the same number of filenames as there are ",
            "labelled_files."))
    }
    if (missing(barcode_decision)) {
        stop(paste0(
            "Must specify barcode_decision present in labelled_files. ",
            "This is either: Barcode_MAP_dup, Barcode_MAP_nodup, or ",
            "Barcode_MWBM."))
    }
    ## Error-checking for qstandard, qstandard_col and subtract_constant
    qstandard_col <- gsub("\\s+", ".", qstandard_col)
    if (any(lib_cols %in% fnorm_vector)) {
        if (missing(qstandard) | missing(qstandard_col)) {
            stop(paste0(
                "Must specify a qstandard  and qstandard_col because the ",
                "model contains features that are normalized to an ",
                "internal standard."))
        }
    }
    if ("Subtracted.RT" %in% lib_cols) {
        if (missing(subtract_constant)) {
            stop(paste0(
                "Must specify subtract_constant because subtracted.RT is a ",
                "feature used in the model."))
        }
    }

    ## Compute normalized feature columns in all labelled_files
    features <- lib_cols[lib_cols %in% fnorm_vector]
    if (length(features) > 0) {
        for (i in seq_along(labelled_files)) {
            colnames(labelled_files[[i]]) <- gsub(
                "\\s+", ".", colnames(labelled_files[[i]]))
            labelled_files[[i]] <- nb_label_peaks_normalize_file(
                loaded = labelled_files[[i]],
                features = features,
                fnorm = fnorm_vector,
                qstandard = qstandard,
                qstandard_col = qstandard_col,
                subtract_constant = subtract_constant)
        }
    }

    ## Split Mass.Info into Q1/Q3, add Detected column, add Filename column,
    ## and add Barcode based on the chosen Barcode_MAP_dup/MAP_nodup/MWBM
    for (i in seq_along(labelled_files)) {
        colnames(labelled_files[[i]]) <- gsub(
            "\\s+", ".", colnames(labelled_files[[i]]))
        labelled_files[[i]][
            , c("Q1", "Q3") := tstrsplit(gsub("\\s+", "", Mass.Info), "/")]
        labelled_files[[i]][, Q1 := as.numeric(Q1)]
        labelled_files[[i]][, Q3 := as.numeric(Q3)]
        features <- lib_cols[lib_cols %in% feature_norm[, 1]]
        labelled_files[[i]][, "Detected" := TRUE]
        labelled_files[[i]][
            , Detected := !(all(is.na(.SD)))
            , .SDcols = detected_col
            , by = seq_len(nrow(labelled_files[[i]]))]
        labelled_files[[i]][, "Filename" := filenames[i]]
        setnames(labelled_files[[i]], barcode_decision, "Barcode")
    }

    ## Determine if all columns from labelled file match and rbind to library
    for (i in seq_along(labelled_files)) {
        temp_cols <- colnames(labelled_files[[i]])
        if (!(all(lib_cols %in% temp_cols))) {
            stop(paste0(
                "The following columns are not present in the labelled ",
                "files:\n",
                lib_cols[!(lib_cols %in% temp_cols)]))
        }
        keep_cols <- c("Filename", "Barcode", lib_cols)
        labelled_files[[i]] <- labelled_files[[i]][, (keep_cols), with = FALSE]
        #labelled_files[[i]][, "Keep" := TRUE]
        #labelled_files[[i]][Barcode == "UNASSIGNED", Keep := FALSE]
        #labelled_files[[i]] <- labelled_files[[i]][Keep == TRUE]
        #labelled_files[[i]][, "Keep" := NULL]
        library <- rbind(library, labelled_files[[i]])
    }

    ## Remove blank rows if these are somehow scanned in
    library <- library[!(apply(is.na(library) | library == "", 1, all)), ]

    return(library)
}
