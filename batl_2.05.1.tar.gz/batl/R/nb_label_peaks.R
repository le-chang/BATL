#' nb_label_peaks
#'
#' @description Label a vector of peak files using a trained BATL model.
#'
#' @usage
#' nb_label_peaks(
#'     filenames,
#'     model_filename,
#'     qstandard,
#'     qstandard_col,
#'     subtract_constant,
#'     exceptions,
#'     ...)
#'
#' @param filenames Vector of peak files to label.
#' @param model_filename Name of trained BATL model.
#' @param qstandard Internal standard for feature normalization.
#' @param qstandard_col Column name where the internal standard is indicated.
#' @param subtract_constant Constant for subtracted retention time feature
#' @param exceptions Keyword exceptions in the "Mass Info" column indicating
#' rows to exclude from labelling.
#' @param ... Advanced argument to specify which features should be normalized
#' to the internal standard. Default setting normalizes "Area", "Height",
#' "Relative.RT", and "Subtracted.RT" using the internal standard.
#'
#' @details
#' \tabular{lll}{
#' filenames \tab \tab Character vector. \cr
#' model_filename \tab \tab String. \cr
#' qstandard \tab \tab String. \cr
#' qstandard_col \tab \tab String. \cr
#' subtract_constant \tab \tab Numeric. \cr
#' exceptions \tab \tab Character vector. \cr
#' ... \tab \tab 2 column matrix with column names "Feature" and "Normalize".\cr
#' \tab \tab 1st column contains the feature names. 2nd column TRUE/FALSE. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_label_peaks

nb_label_peaks <- function(
    filenames, model_filename, qstandard, qstandard_col, subtract_constant,
    exceptions, ...) {

    ## Null strategy to pass R CMD check
    tolerance <- NULL

    ## Error-checking
    if (missing(filenames)) {
        stop("Must specify filenames")
    }
    if (missing(model_filename)) {
        stop("Must specify nb_model_file")
    }
    if (!(is.character(model_filename))) {
        stop("nb_model_file must be a string.")
    }
    if (missing(exceptions)) {
        exceptions <- character()
    }

    ## Capture unevaluated expression about which features get normalized to the
    ## internal standard qstandard
    params <- list(...)
    if ("feature_norm" %in% names(params)) {
        feature_norm <- params[[which(names(params) %in% "feature_norm")]]
    } else {
        feature_norm <- matrix(c(
            "Retention Time", FALSE,
            "Area", TRUE,
            "Height", TRUE,
            "Width at 50%", FALSE,
            "Tailing Factor", FALSE,
            "Asymmetry Factor", FALSE,
            "Relative RT", TRUE,
            "Subtracted RT", TRUE),
            ncol = 2,
            byrow = TRUE,
            dimnames = list(c(), c("Feature", "Normalize")))
    }

    ## Load selected model
    nb_model <- nb_import_model(model_name = model_filename)

    ## Extract model features
    feature_vector <- nb_label_peaks_extract_row(
        model_meta_info = nb_model$Meta_information,
        string = "features")

    ## Error-checking for qstandard qstandard_col and subtract_constant
    fnorm_vector <- feature_norm[feature_norm[, "Normalize"] == TRUE, "Feature"]
    fnorm_vector <- gsub("\\s+", ".", fnorm_vector)
    if (any(feature_vector %in% fnorm_vector)) {
        if (missing(qstandard) | missing(qstandard_col)) {
            stop(paste0(
                "Must specify a qstandard  and qstandard_col because the ",
                "model contains features that are normalized to an ",
                "internal standard."))
        }
        qstandard_col <- gsub("\\s+", ".", qstandard_col)
    }
    if ("Subtracted.RT" %in% feature_vector) {
        if (missing(subtract_constant)) {
            stop(paste0(
                "Must specify subtract_constant because subtracted.RT is a ",
                "feature used in the model."))
        }
    }
    if (missing(qstandard)) {
        qstandard <- ""
    }
    if (missing(qstandard_col)) {
        mandatory_cols <- c(
            "Index", "Sample.Index", "Sample.Name", "Mass.Info")
        qstandard_col <- ""
    } else {
        mandatory_cols <- c(
            "Index", "Sample.Index", "Sample.Name", "Mass.Info",
            qstandard_col)
    }

    ## Check for the first 4-5 mandatory columns in the peak files
    for (kFile in seq_along(filenames)) {
        loaded <- nb_label_peaks_load(filename = filenames[kFile])
        colnames(loaded) <- gsub("\\s+", ".", colnames(loaded))
        check_vec <- mandatory_cols %in% colnames(loaded)
        if (any(check_vec == FALSE)) {
            stop(paste0(
                "The following column(s) are missing in the peak files:\n",
                paste0(mandatory_cols[check_vec == FALSE], collapse = ", ")))
        }
    }

    ## Extract decision rule(s)
    decision_vector <- nb_label_peaks_extract_row(
        model_meta_info = nb_model$Meta_information,
        string = "decision")

    ## Extract tolerance
    tolerance_vector <- nb_label_peaks_extract_row(
        model_meta_info = nb_model$Meta_information,
        string = "tolerance")
    tolerance_vector <- as.numeric(tolerance_vector)

    ## Extract pseudocount
    pseudocount_vector <- nb_label_peaks_extract_row(
        model_meta_info = nb_model$Meta_information,
        string = "pseudocount")
    pseudocount_vector <- as.numeric(pseudocount_vector)

    ## Extract logged features
    log_vector <- nb_label_peaks_extract_row(
        model_meta_info = nb_model$Meta_information,
        string = "logged features")

    ## Reshape model (transition-specific cutoffs as new rows)
    nb_model$Model <- nb_label_peaks_reshape_model(
        nb_model_only = nb_model$Model)

    ## Add Q1/Q3 tolerance columns to the model
    nb_model$Model <- nb_build_model_q13_tolerance(
        dt = nb_model$Model, tolerance = tolerance_vector)

    ## Initialize output list
    filenames_labelled <- vector("list", length = length(filenames))

    ## Iteratively label each file
    for (kFile in seq_along(filenames)) {
        filenames_labelled[[kFile]] <- nb_label_peaks_with_model(
            filename = filenames[kFile],
            nb_model_only = nb_model$Model,
            qstandard = qstandard,
            qstandard_col = qstandard_col,
            features = feature_vector,
            decision = decision_vector,
            tolerance = tolerance_vector,
            pseudocount = pseudocount_vector,
            log_vector = log_vector,
            subtract_constant = subtract_constant,
            exceptions = exceptions,
            fnorm = fnorm_vector)
    }

    return(filenames_labelled)
}
