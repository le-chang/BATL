#' nb_import_labelled_file
#'
#' @description Wrapper function to import a labelled peak file.
#'
#' @usage
#' nb_import_labelled_file(labelled_file)
#'
#' @param labelled_file Name and path of labelled peak file.
#'
#' @details
#' \tabular{lll}{
#' labelled_file \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export nb_import_labelled_file
#'

nb_import_labelled_file <- function(labelled_file) {
    labelled_file <- fread(
        file = labelled_file,
        header = TRUE,
        sep = "\t",
        na.strings = "N/A",
        stringsAsFactors = FALSE)

    return(labelled_file)
}
