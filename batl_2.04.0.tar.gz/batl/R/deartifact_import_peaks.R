#' deartifact_import_peaks
#'
#' @description Wrapper function to import a peak file from
#' \emph{deartifact_peaks}.
#'
#' @usage
#' deartifact_import_peaks(filename)
#'
#' @param filename Name and path of output text file (ending in *.txt).
#'
#' @details
#' \tabular{lll}{
#' filename \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export deartifact_import_peaks
#'

deartifact_import_peaks <- function(filename) {
    filename <- fread(
        file = filename,
        header = TRUE,
        sep = "\t",
        na.strings = "N/A",
        stringsAsFactors = FALSE)

    return(filename)
}
