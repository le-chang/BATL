#' nb_import_model
#'
#' @description Wrapper function to import a BATL model from a text file.
#'
#' @usage
#' nb_import_model(model_name)
#'
#' @param model_name Name and path of the BATL model.
#'
#' @details
#' \tabular{lll}{
#' model_name \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @importFrom data.table fread
#' @export nb_import_model
#'

nb_import_model <- function(model_name) {

    ## Null strategy to pass R CMD check
    Barcode <- NULL

    ## Error-checking
    if (missing(model_name)) {
        stop("Must specify model_name.")
    }
    if (!(is.character(model_name))) {
        stop("model_name must be a string.")
    }

    ## Initialize output 2-element list
    list_2 <- vector("list", length = 2L)

    ## Parse data and get index of last meta information line
    meta <- readLines(con = model_name)
    meta_ele <- substr(meta, 1, 1)
    meta_last_line <- length(meta_ele) - match("#", rev(meta_ele)) + 1
    list_2[[2]] <- meta[seq_len(meta_last_line)]
    names(list_2)[2] <- "Meta_information"

    ## Load model
    #my_model <- read.table(
        #file = model_name,
        #header = TRUE,
        #sep = "\t",
        #skip = meta_last_line,
        #stringsAsFactors = FALSE)
    my_model <- fread(
        file = model_name,
        header = TRUE,
        sep = "\t",
        skip = meta_last_line,
        stringsAsFactors = FALSE)
    my_model <- as.data.table(my_model)
    list_2[[1]] <- my_model
    names(list_2)[1] <- "Model"
    list_2$Model[, Barcode := as.character(Barcode)]

    return(list_2)
}
