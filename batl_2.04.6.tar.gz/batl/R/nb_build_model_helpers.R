## Get all feature combinations (exhaustive or not)
nb_build_model_feature_combinations <- function(exhaustive, features) {

    ## Apply white space substitution
    features <- gsub("\\s+", ".", features)

    ## Feature combinations
    if (exhaustive == TRUE) {
        fcombinations <- vector("list", length = length(features))
        for (kLen in seq_along(features)) {
            fcombinations[[kLen]] <- combn(
                x = features,
                m = kLen,
                simplify = FALSE)
        }
    } else if (exhaustive == FALSE) {
        fcombinations <- vector("list", length = 1L)
        fcombinations[[1]] <- list(features)
    }

    return(fcombinations)
}

## Split library into cross validation folds
nb_build_model_cv_split <- function(library, folds) {
    library_names <- sample(library[, unique(Sample.Name)])

    ## Null strategy to pass R CMD check
    Sample.Name <- Barcode <- NULL

    if (length(library_names) == 0) {
        stop(paste0(
            "There are no samples in the library."))
    } else if (length(library_names) < 3) {
        stop(paste0(
            "Less than 3 samples are contained in the library and cannot ",
            "accurately estimate Gaussian likelihoods. If subsetting by ",
            "qmatrix, ensure the library contains the appropriate matrices."))
    }

    table_barcodes <- which(table(library[, Barcode]) < 3)
    if (length(table_barcodes) > 0) {
        message(paste0(
            "One or more barcodes are present less than 3 times in the ",
            "library. Unless more observations ",
            "are present, the following barcodes will never be assigned:\n",
            paste0(names(table_barcodes), collapse = ", ")))
    }

    if (folds > length(library_names)) {
        message(paste0(
            "# folds > # samples. Defaulting the number of folds to the # of ",
            "samples for leave-one-out cross validation."))
        folds <- length(library_names)
    }

    ## Create equally-sized folds based on sample name
    fold_list <- split(
        library_names,
        cut(seq_along(library_names),
            folds,
            labels = FALSE))

    return(fold_list)
}

## Create cluster
nb_build_model_create_cluster <- function(log_path, parallel_cores) {

    ## Create cluster
    if (log_path != "") {
        cl <- makeCluster(
            parallel_cores,
            type = "PSOCK",
            outfile = paste0(log_path, "/std.log"))
        #dir.create(paste0(save_path, "/folds"), showWarnings = FALSE)
    } else {
        cl <- makeCluster(parallel_cores, type = "PSOCK")
    }
    registerDoParallel(cl)
    return(cl)
}

## Initialize output lists
nb_build_model_init_cv_output <- function(fcombinations) {

    ## Output table to store model containing:
    ## Barcode, Q1, Q3, Gaussian parameters, prior, and posterior cutoff
    model_fcombinations <- vector(
        "list", length = sum(lengths(fcombinations)))

    ## Output table to store final decision/assignments
    all_assignments <- data.table()
    all_assignments <- lapply(
        seq_len(sum(lengths(fcombinations))),
        function(x) copy(all_assignments))

    return(list(
        model_fcombinations = model_fcombinations,
        all_assignments = all_assignments))
}


## Create testing and training folds
nb_build_model_get_folds <- function(fold_list, kFold, fcombinations, library) {

    ## Null strategy to pass R CMD check
    Sample.Name <- NULL

    ## lFold contains all samples to be treated as testing data
    lFold <- fold_list[[kFold]]

    ## Split library into testing and training
    testing <- library[Sample.Name %in% lFold]
    remain_names <- copy(fold_list)
    remain_names <- as.vector(do.call("c", remain_names))
    remain_names <- remain_names[!(remain_names %in% lFold)]
    training <- library[Sample.Name %in% remain_names]

    return(list(
        training = training,
        testing = testing))
}

## Add Q1 and Q3 tolerance columns
nb_build_model_q13_tolerance <- function(dt, tolerance) {

    ## Null strategy to pass R CMD check
    Q1 <- Q3 <- NULL

    if (!(all(c("Q1", "Q3") %in% colnames(dt)))) {
        stop("Q1 and Q3 must be present as data table columns.")
    }
    dt[, Q1 := as.numeric(Q1)]
    dt[, Q3 := as.numeric(Q3)]
    dt[, "Q1.min" := Q1 - tolerance]
    dt[, "Q1.max" := Q1 + tolerance]
    dt[, "Q3.min" := Q3 - tolerance]
    dt[, "Q3.max" := Q3 + tolerance]
}

## Estimate priors by maximum likelihood estimation with additive smoothing
nb_build_model_estimate_priors <- function(training_copy, pseudocount) {

    ## Null strategy to pass R CMD check
    Missing <- NULL

    training_copy[
        , "Numerator" := .N, by = c("Q1", "Q3", "Barcode")]
    denom <- nrow(unique(
        training_copy, by = c("Filename", "Sample.Index", "Sample.Name")))
    training_copy[, "Prior" := Numerator / denom]
    training_copy[, "Numerator" := NULL]
}

## Initialize likelihood column for merging with testing set
nb_build_model_init_likelihood <- function(training_copy) {

    likelihood <- unique(training_copy, by = "Barcode")
    likelihood <- likelihood[, c("Barcode", "Q1", "Q3", "Prior")]

    likelihood[[1]] <- as.character(likelihood[[1]])
    likelihood[[2]] <- as.numeric(likelihood[[2]])
    likelihood[[3]] <- as.numeric(likelihood[[3]])
    likelihood[[4]] <- as.numeric(likelihood[[4]])

    return(likelihood)
}

## Determine if the following columns should be log transformed for normality
nb_build_model_log_transform <- function(
    training_copy, testing_copy, feature_col) {

    ## Null strategy to pass R CMD check
    Value_linear <- Value_log <- Mean_linear <- Mean_log <- NULL
    Sd_linear <-  Sd_log <- Detected <- KS_pvalue_linear <- NULL
    KS_pvalue_log <- Feature <- NULL

    ## Optional flow for |nb_build_model_full|
    if (is.null(testing_copy)) {
        no_test <- TRUE
    } else {
        no_test <- FALSE
    }
    ## KS-test threshold of 5%
    ks_threshold <- 0.05
    feature_log <- vector("logical", length = length(feature_col))

    ## Log transform feature if it improves overall lipid normality
    for (kFeature in seq_along(feature_col)) {

        temp_name <- colnames(training_copy)[feature_col[kFeature]]
        setnames(training_copy, feature_col[kFeature], "Value_linear")
        training_copy[, Value_linear := as.numeric(Value_linear)]
        training_copy[, "Value_log" := log(Value_linear)]
        training_copy[
            , "Mean_linear" := mean(Value_linear, na.rm = TRUE)
            , by = "Barcode"]
        training_copy[
            , "Mean_log" := mean(Value_log, na.rm = TRUE)
            , by = "Barcode"]
        training_copy[is.nan(Mean_linear), Mean_linear := NA]
        training_copy[is.nan(Mean_log), Mean_log := NA]
        training_copy[
            , Sd_linear := sd(Value_linear, na.rm = TRUE)
            , by = "Barcode"]
        training_copy[
            , Sd_log := sd(Value_log, na.rm = TRUE)
            , by = "Barcode"]
        suppressWarnings(
            training_copy[
                !(is.na(Value_linear))
                , "KS_pvalue_linear" := ks.test(
                    Value_linear,
                    "pnorm",
                    Mean_linear,
                    Sd_linear)[2]
                , by = "Barcode"]
        )
        suppressWarnings(
            training_copy[
                !(is.na(Value_log))
                , "KS_pvalue_log" := ks.test(
                    Value_log,
                    "pnorm",
                    Mean_log,
                    Sd_log)[2]
                , by = "Barcode"]
        )
        training_temp <- training_copy
        training_temp <- unique(training_temp, by = "Barcode")
        linear <- training_temp[
            , sum(KS_pvalue_linear > ks_threshold, na.rm = TRUE) / .N]
        log <- training_temp[
            , sum(KS_pvalue_log > ks_threshold, na.rm = TRUE) / .N]

        ## Transform library AND filename feature if necessary
        if (log > linear) {
            message(paste0("Log transform applied to feature: ", temp_name))
            feature_log[kFeature] <- TRUE
            training_copy[, Value_linear := log(Value_linear)]

            if (no_test == FALSE) {
                setnames(testing_copy, temp_name, "Feature")
                testing_copy[, Feature := log(Feature)]
                setnames(testing_copy, "Feature", temp_name)
            } else {
                testing_copy <- NULL
            }
        }
        setnames(training_copy, "Value_linear", temp_name)
        training_copy[
            , c(
                "Mean_linear",
                "Mean_log",
                "Sd_linear",
                "Sd_log",
                "Value_log",
                "KS_pvalue_linear",
                "KS_pvalue_log") := NULL]
    }
    return(list(
        training_copy = training_copy,
        testing_copy = testing_copy,
        feature_log = feature_log))
}

## Compute Gaussian parameters
nb_build_model_gaussian_parameters <- function(
    training_copy, feature_col_idx, likelihood) {

    ## Null strategy to pass R CMD check
    Value <- Q1 <- Q3 <- Mean <- Variance <- Barcode <- NULL

    ## Get feature name for data table manipulation
    feature_name <- colnames(training_copy)[feature_col_idx]
    setnames(training_copy, feature_name, "Value")

    ## Ensure numeric columns
    training_copy[
        , Value := as.numeric(Value)]
    training_copy[, Q1 := as.numeric(Q1)]
    training_copy[, Q3 := as.numeric(Q3)]

    ## Gaussian mean
    training_copy[
        , Mean := mean(Value, na.rm = TRUE)
        , by = "Barcode"]

    ## Gaussian variance
    training_copy[
        , Variance := var(Value, na.rm = TRUE)
        , by = "Barcode"]

    ## If NaN, convert Mean to NA (occurs with lipid standard barcodes when
    ## they are normalized to themselves)
    training_copy[is.nan(Mean), Mean := NA]

    ## Subset only important columns for merging
    training_copy <- training_copy[
        , c("Barcode", "Q1", "Q3", "Mean", "Variance")]

    ## Left join mean and variance to likelihood and rename columns
    setkey(likelihood, Barcode, Q1, Q3)
    setkey(training_copy, Barcode, Q1, Q3)
    likelihood <- merge(likelihood, training_copy, all.x = TRUE)
    likelihood <- unique(likelihood, by = c("Q1", "Q3", "Barcode"))
    setnames(likelihood, "Mean", paste0(feature_name, "_mean"))
    setnames(likelihood, "Variance", paste0(feature_name, "_variance"))

    return(likelihood)
}

## Initialize return data table of all peak assignments and final assignments
nb_build_model_init_output <- function(training_copy, feature_col, overlap) {

    ## Null strategy to pass R CMD check
    Index <- Barcode <- Sample.Index <- Sample.Name <- Barcode_true <- NULL
    Q1 <- Q3 <- Prior <- NULL

    ## Initialize return table of priors and likelihood for
    ## candidate assignments
    return_names <- colnames(training_copy)[feature_col]
    return_names_combined <- paste0(
        rep(return_names, each = 4),
        c("", ".Value", ".Mean", ".Variance"))

    return <- matrix(
        NA,
        nrow = nrow(overlap),
        ncol = ((length(feature_col) * 4) + 8),
        dimnames = list(
            c(), c(
                "Index", "Barcode", "Sample.Index", "Sample.Name",
                "Barcode_true", "Q1", "Q3", "Prior", return_names_combined)))
    return[, 1] <- overlap[, Index]
    return[, 2] <- overlap[, Barcode]
    return[, 3] <- overlap[, Sample.Index]
    return[, 4] <- overlap[, Sample.Name]
    return[, 5] <- overlap[, Barcode_true]
    return[, 6] <- overlap[, Q1]
    return[, 7] <- overlap[, Q3]
    return[, 8] <- overlap[, Prior]

    return(list(return = return, return_names = return_names))
}

nb_build_model_gaussian_likelihood <- function(
    return, overlap, training_copy, feature_col_idx, kFeature) {

    ## Null strategy to pass R CMD check
    Variance <- Value <- Mean <- Likelihood <- NULL

    ## Get column names for manipulation
    feature_name <- colnames(training_copy)[feature_col_idx]
    feature_mean <- paste0(feature_name, "_mean")
    feature_variance <- paste0(feature_name, "_variance")
    setnames(
        overlap,
        colnames(overlap)[which(colnames(overlap) == feature_name)],
        "Value")
    setnames(
        overlap,
        colnames(overlap)[which(colnames(overlap) == feature_mean)],
        "Mean")
    setnames(
        overlap,
        colnames(overlap)[
            which(colnames(overlap) == feature_variance)],
        "Variance")

    ## Calculate Gaussian likelihood function
    overlap[
        , "Likelihood" := (
            (1 / (sqrt(2 * pi * Variance))) *
                exp((-1 / 2) * ((Value - Mean)^2) / (Variance)))]

    ## Lipid standards normalized to themselves will return 'NaN'
    ## Set 'NaN' to likelihood of 1.
    overlap[is.nan(Likelihood), Likelihood := 1]

    ## Include parameters, feature values, and likelihoods
    return[, (8 + ((kFeature - 1) * 4) + 1)] <- overlap[
        , Likelihood]
    return[, (8 + ((kFeature - 1) * 4) + 2)] <- overlap[, Value]
    return[, (8 + ((kFeature - 1) * 4) + 3)] <- overlap[, Mean]
    return[, (8 + ((kFeature - 1) * 4) + 4)] <- overlap[, Variance]

    ## Reset column names
    setnames(overlap, "Value", feature_name)
    setnames(overlap, "Mean", feature_mean)
    setnames(overlap, "Variance", feature_variance)

    return(return)
}

## Calculate numerator of naive Bayes posterior probability
nb_build_model_posterior_prob <- function(return, return_names) {

    ## Null strategy to pass R CMD check
    Not_detected <- Prior <- Missing_data <- Barcode <- NULL
    Missing_likelihood <- Barcode_NA <- Posterior <- NULL

    ## Ensure data.table object
    return <- as.data.table(return)

    ## Coerce all likelihood columns to numerics
    for (kCol in as.integer(c(1, 8:ncol(return)))) {
        set(
            return,
            j = kCol,
            value = as.numeric(return[[kCol]]))
    }

    ## Calculate unnormalized posteriors for every row in the data table
    ## based on the feature likelihood value column and the prior
    return[, "Posterior" := NA_real_]
    return[
        , Posterior := prod(.SD, na.rm = TRUE)
        , .SDcols = c("Prior", return_names)
        , by = seq_len(nrow(return))]

    ## Get feature names with '.Value' at the end
    return_value_names <- paste0(return_names, ".Value")

    ## If all feature '.Value' are NA, set the posterior to NA because a
    ## peak was never even detected at that transition
    return[
        , "Not_detected" := all(is.na(.SD))
        , .SDcols = c(return_value_names)
        , by = seq_len(nrow(return))]
    return[
        Not_detected == TRUE
        , Posterior := NA_real_]

    ## If the prior probability is 0, the likelihood function cannot be
    ## evaluated so the posterior is set to NA as well
    return[, "Missing_data" := ifelse(Prior == 0, TRUE, FALSE)]
    return[
        Missing_data == TRUE
        , Posterior := NA_real_]
    return[, "Missing_data" := NULL]

    ## If a peak is detected but the likelihood function is NA, set the
    ## posterior to NA. Also make sure this only applies to real barcodes
    ## (not Barcode_NA)
    return[
        , "Barcode_NA" := ifelse(
            grepl("Barcode_NA", Barcode, fixed = TRUE), TRUE, FALSE)]
    return[
        , "Missing_likelihood" := all(is.na(.SD))
        , .SDcols = c(return_names)
        , by = seq_len(nrow(return))]
    return[
        Missing_likelihood == TRUE & Not_detected == FALSE &
            Barcode_NA == FALSE
        , Posterior := NA_real_]
    return[, c("Missing_likelihood", "Barcode_NA", "Not_detected") := NULL]

    return(return)
}

## Reshape posterior cutoffs
nb_build_model_reshape_cutoff <- function(return) {

    ## Null strategy to pass R CMD check
    Barcode <- Index <- Posterior <- Magnitude <- NULL

    ## Unique-ify NA names for decision rules
    return[
        Barcode == "Barcode_NA"
        , Barcode := paste("NA", Index, sep = "_")]

    ## Make sure the transition cutoffs are slightly smaller than the
    ## empirically observed minimum cutoff of successful assignment
    return[, "Magnitude" := floor(log10(Posterior))]
    return[
        Posterior >= 1e0 & grepl("NA_", Barcode, fixed = TRUE)
        , Posterior := Posterior - 0.001 * 10^(Magnitude)]
    return[, "Magnitude" := -floor(log10(Posterior))]
    return[
        Posterior < 1e0 & grepl("NA_", Barcode, fixed = TRUE)
        , Posterior := Posterior - 0.001 * 10^(-Magnitude)]
    return[, "Magnitude" := NULL]
}

## Estimate transition-specific posterior cutoffs
nb_build_model_estimate_cutoff <- function(output) {

    ## Null strategy to pass R CMD check
    Posterior <- Barcode <- Barcode_true <- Keep <- NULL
    Posterior_cutoff <- NULL
    Barcode <- NULL

    ## Initialize output data table (every transition in training data)
    transition_cutoff <- output[, 0L, by = c("Q1", "Q3")]
    transition_cutoff[, "V1" := NULL]

    output_cutoff <- output[!(is.na(Posterior)) & Barcode == Barcode_true]
    output_cutoff[, "Keep" := min(Posterior), by = c("Q1", "Q3")]
    output_cutoff <- output_cutoff[
        Keep == Posterior
        , c("Q1", "Q3", "Posterior")]
    setnames(output_cutoff, "Posterior", "Posterior_cutoff")

    ## Filter out any resulting duplicates
    output_cutoff <- unique(output_cutoff)

    ## Merge total transition list with those with posterior cutoffs
    setkey(transition_cutoff, "Q1", "Q3")
    setkey(output_cutoff, "Q1", "Q3")
    transition_cutoff <- merge(transition_cutoff, output_cutoff, all.x = TRUE)

    ## Note that there could be some transitions with NA posteriors because:
    ## (i) testing data does not contain training barcode at a transition so
    ## the testing peak always incorrectly matches a training barcode
    ## (ii) no peaks at a given transition are detected so decision algorithms
    ## assign NA
    ## These problems are generally found when the training data does not
    ## contain more than 3 instances of a detected barcode
    ## During these cases, we set the transition-specific cutoff to be +Inf
    transition_cutoff[is.na(Posterior_cutoff), Posterior_cutoff := +Inf]

    return(transition_cutoff)
}

## Extract barcodes, Q1, Q3, priors, likelihood parameters, transition cutoffs
nb_build_model_extract <- function(output, transition_cutoff) {

    ## Null strategy to pass R CMD check
    Barcode <- Remove <- Q1 <- Q3 <- NULL

    my_cols <- colnames(output)
    feature_mean <- grep(".Mean$", my_cols)
    feature_mean <- my_cols[feature_mean]
    feature_var <- grep(".Variance$", my_cols)
    feature_var <- my_cols[feature_var]
    feature_cols <-  c(rbind(feature_mean,feature_var))

    my_model <- output[
        , c("Barcode", "Q1", "Q3", "Prior", feature_cols)
        , with = FALSE]
    my_model <- my_model[!(is.na(Barcode))]
    my_model <- unique(my_model)

    my_model[, "Remove" := FALSE]
    my_model[
        , Remove := all(is.na(.SD))
        , .SDcols = c(feature_var)
        , by = seq_len(nrow(my_model))]
    my_model <- my_model[Remove == FALSE]
    my_model[, "Remove" := NULL]

    ## Join current_model and cutoff
    setkey(my_model, Q1, Q3)
    setkey(transition_cutoff, Q1, Q3)
    my_model <- merge(
        my_model, transition_cutoff, all.x = TRUE)

    return(my_model)
}

## Unlist output and combine across folds
nb_build_model_unlist_results <- function(results, full_output) {

    ## Null strategy to pass R CMD check

    ## Unlist output and combine across folds
    results <- unlist(results, recursive = FALSE)

    ## Separate list into all assignments and cutoff
    results2 <- results[names(results) %in% "assignments"]
    results <- results[names(results) %in% "model"]

    ## Final assignment list; rbind folds across different feature combinations
    if (full_output == TRUE) {
        all <- vector("list", length = unique(length(results2)))
        all <- lapply(
            seq_len(unique(lengths(results2))), function(x) copy(all))

        for (kFold in seq_along(results2)) {
            for (kComb in seq_len(length(results2[[kFold]]))) {
                all[[kComb]][[kFold]] <- results2[[kFold]][[kComb]]
                names(all)[[kComb]] <- names(results2[[kFold]][kComb])
            }
        }
        for (kComb in seq_along(all)) {
            all[[kComb]] <- do.call("rbind", all[[kComb]])
        }
        rm(results2)
    }

    ## Final output list; rbind folds across different feature combinations
    output <- vector("list", length = unique(length(results)))
    output <- lapply(
        seq_len(unique(lengths(results))), function(x) copy(output))

    for (kFold in seq_along(results)) {
        for (kComb in seq_len(length(results[[kFold]]))) {
            output[[kComb]][[kFold]] <- results[[kFold]][[kComb]]
            names(output)[[kComb]] <- names(results[[kFold]][kComb])
        }
    }
    for (kComb in seq_along(output)) {
        output[[kComb]] <- do.call("rbind", output[[kComb]])
    }
    rm(results)

    return(list(output = output, all = all))
}

## Find the smallest posterior cutoffs for each model
nb_build_model_full_cutoff <- function(output_idx) {

    ## Null strategy to pass R CMD check
    output <- kComb <- Posterior_cutoff <- Keep <- NULL

    output_copy <- copy(output_idx)
    output_copy[, "Keep" := min(Posterior_cutoff), by = c("Q1", "Q3")]
    output_copy <- output_copy[Posterior_cutoff == Keep]
    by_names <- colnames(output_copy)
    by_names <- by_names[!(by_names %in% "Fold")]
    output_copy <- unique(output_copy, by = (by_names))
    output_copy <- output_copy[, c("Q1", "Q3", "Posterior_cutoff")]
    return(output_copy)
}

## Generate naive Bayes model parameters/priors with the full dataset
## and append cutoffs
nb_build_model_full <- function(library, pseudocount, features, cutoff) {

    ## Null strategy to pass R CMD check
    Remove <- Q1 <- Q3 <- NULL

    ## Copy because iterating over the same library object
    library_copy <- copy(library)

    ## Estimate prior probabilities with additive smoothing
    library_copy <- nb_build_model_estimate_priors(
        training_copy = library_copy, pseudocount = pseudocount)

    ## Initialize list of gaussian likelihood parameters for each file
    likelihood <- nb_build_model_init_likelihood(training_copy = library_copy)

    ## Figure out feature column indices from the library
    feature_col <- which(colnames(library_copy) %in% features)

    ## Determine whether to log transform based on training set features
    list_3 <- nb_build_model_log_transform(
        training_copy = library_copy,
        testing_copy = NULL,
        feature_col = feature_col)
    library <- list_3$library_copy
    feature_log <- list_3$feature_log

    ## Calculate likelihood parameters per feature and add to likelihood table
    for (kFeature in seq_along(feature_col)) {
        likelihood <- nb_build_model_gaussian_parameters(
            training_copy = copy(library_copy),
            feature_col_idx = feature_col[kFeature],
            likelihood = likelihood)
    }

    ## Remove any rows with NA mean and variance
    feature_mean <- grep("_mean$", colnames(likelihood))
    feature_mean <- colnames(likelihood)[feature_mean]
    feature_var <- grep("_variance$", colnames(likelihood))
    feature_var <- colnames(likelihood)[feature_var]
    likelihood[, "Remove" := FALSE]
    likelihood[
        , "Remove" := any(is.na(.SD))
        , .SDcols = c(feature_mean, feature_var)
        , by = seq_len(nrow(likelihood))]
    likelihood <- likelihood[Remove == FALSE]
    likelihood[, "Remove" := NULL]

    ## Join cutoffs
    likelihood[, Q1 := as.numeric(Q1)]
    likelihood[, Q3 := as.numeric(Q3)]
    cutoff[, Q1 := as.numeric(Q1)]
    cutoff[, Q3 := as.numeric(Q3)]
    setkey(likelihood, Q1, Q3)
    setkey(cutoff, Q1, Q3)
    likelihood <- merge(likelihood, cutoff, all.x = TRUE)
    likelihood <- unique(likelihood)

    ## Re-order columns
    feature_cols <- c(rbind(feature_mean, feature_var))
    setcolorder(
        likelihood
        , c("Q1", "Q3", "Barcode", "Prior", feature_cols, "Posterior_cutoff"))

    return(list(likelihood = likelihood, feature_log = feature_log))
}

## Meta information for each model
nb_build_model_meta <- function(
    features, decision, library, function_start, function_end, folds,
    exhaustive, tolerance, parallel_cores, full_output, log_path,
    pseudocount, log_vec) {

    ## Null strategy to pass R CMD check
    Filename <- NULL

    if (length(features) > 1) {
        meta_feat <- paste(features, collapse = ", ")
    } else {
        meta_feat <- features
    }
    if (length(decision) > 1) {
        meta_dec <- paste(decision, collapse = ", ")
    } else {
        meta_dec <- decision
    }
    if (length(log_vec) > 1) {
        meta_log <- paste(log_vec, collapse = ", ")
    } else {
        meta_log <- log_vec
    }
    if (full_output == "") {
        meta_output <- cat("\"\"")
    }
    meta_samples <- nrow(
        unique(
            library,
            by = c("Filename", "Sample.Index", "Sample.Name")))
    meta_peaks <- nrow(
        unique(
            library,
            by = c(
                "Filename",
                "Index",
                "Sample.Index",
                "Sample.Name")))
    meta_filenames <- library[, unique(Filename)]
    meta_filenames <- sapply(strsplit(meta_filenames, "/"), tail, 1)
    meta_filenames <- paste0("# ", meta_filenames)
    meta_transitions <- nrow(unique(library, by = c("Q1", "Q3")))

    meta_vec <- c(
            paste(
                "# This file is generated by BATL version",
                packageDescription("batl")$Version),
            paste(
                "# Date of generation (YYYY-MM-DD):",
                format(Sys.time(), "%Y-%m-%d")),
            paste(
                "# Time in seconds to complete model building and",
                "cross validation:",
                difftime(
                    function_end, function_start, units = "secs")),
            "# Argument list:",
            paste("# folds <-", folds),
            paste0("# features <- c(", meta_feat, ")"),
            paste0("# logged features <- c(", meta_log, ")"),
            paste("# exhaustive <-", exhaustive),
            paste0("# decision <- c(", meta_dec, ")"),
            paste("# tolerance <-", tolerance),
            paste("# parallel_cores <-", parallel_cores),
            paste("# full_output <-", full_output),
            paste("# log_path <-", log_path),
            paste("# pseudocount <-", pseudocount),
            "# Filename information",
            paste(meta_filenames),
            "# Training set information",
            paste("# Total number of samples:", meta_samples),
            paste("# Total number of peaks:", meta_peaks),
            paste(
                "# Total number of unique transitions:",
                meta_transitions)
    )
    return(meta_vec)
}

nb_build_model_nb <- function(
    testing, training, features, decision, tolerance, transition_cutoff,
    pseudocount) {

    ## Null strategy to pass R CMD check
    Q1.min <- Q1.max <- Q3.min <- Q3.max <- Q1 <- Barcode <- NULL
    Prior <- Posterior_cutoff <- NULL

    ## Copy training and testing set
    training_copy <- copy(training)
    testing_copy <- copy(testing)

    ## Get index of feature columns
    feature_col <-  which(colnames(training_copy) %in% features)

    ## Estimate prior probabilities with additive smoothing
    nb_build_model_estimate_priors(
        training_copy = training_copy, pseudocount = pseudocount)

    ## Initialize list of gaussian likelihood parameters for each file
    likelihood <- nb_build_model_init_likelihood(training_copy = training_copy)

    ## Determine whether to log transform based on training set features
    list_3 <- nb_build_model_log_transform(
        training_copy = training_copy,
        testing_copy = testing_copy,
        feature_col = feature_col)
    testing_copy <- list_3$testing_copy
    training_copy <- list_3$training_copy
    feature_log <- list_3$feature_log
    rm(list_3)

    ## Calculate likelihood parameters per feature and add to likelihood table
    for (kFeature in seq_along(feature_col)) {
        likelihood <- nb_build_model_gaussian_parameters(
            training_copy = copy(training_copy),
            feature_col_idx = feature_col[kFeature],
            likelihood = likelihood)
    }

    ## Add placeholder barcode rows corresponding to no assignment if the
    ## transition cutoff parameter specified
    if (is.data.frame(transition_cutoff)) {
        merge_cutoff <- copy(transition_cutoff)
        merge_cutoff[, "Barcode" := "Barcode_NA"]
        merge_cutoff[, Prior := as.numeric(Posterior_cutoff)]
        merge_cutoff[, Posterior_cutoff := NULL]
        likelihood <- rbindlist(list(likelihood, merge_cutoff), fill = TRUE)
    }

    ## Add Q1/Q3 ranges for merging testing and training sets
    nb_build_model_q13_tolerance(dt = likelihood, tolerance = tolerance)
    nb_build_model_q13_tolerance(dt = testing_copy, tolerance = tolerance)

    ## Find all matching lipids from training to testing based on Q1/Q3
    setkey(testing_copy, Q1.min, Q1.max, Q3.min, Q3.max)
    setkey(likelihood, Q1.min, Q1.max, Q3.min, Q3.max)
    overlap <- foverlaps(
        testing_copy,
        likelihood,
        type = "any",
        mult = "all",
        nomatch = NA)
    overlap <- overlap[!(is.na(Q1))]
    colnames(overlap) <- gsub("\\s+", ".", colnames(overlap))

    ## Initialize return table of priors/likelihood for candidate assignments
    list_2 <- nb_build_model_init_output(
        training_copy = training_copy,
        feature_col = feature_col,
        overlap = overlap)
    return_names <- list_2$return_names
    return <- list_2$return
    rm(list_2)

    ## Calculate Gaussian feature likelihood and add to return table
    for (kFeature in seq_along(feature_col)) {
        return <- nb_build_model_gaussian_likelihood(
            return = return,
            overlap = copy(overlap),
            training_copy = training_copy,
            feature_col_idx = feature_col[kFeature],
            kFeature = kFeature)
    }
    rm(overlap)

    ## Compute unnormalized naive Bayes posterior probabilities (numerator)
    return <- nb_build_model_posterior_prob(
        return = return, return_names = return_names)

    ## Modify return dt Barcode names/posteriors if transition_cutoff specified
    if (is.data.frame(transition_cutoff)) {
        nb_build_model_reshape_cutoff(return = return)
    }

    ## Decision rule for final peak-barcode assignment
    if ("MAP_dup" %in% decision) {
        return <- decision_map_dup(return)
    }
    if ("MAP_nodup" %in% decision) {
        return <- decision_map_nodup(return)
    }
    if ("MWBM" %in% decision) {
        return <- decision_mwbm(return)
    }

    ## Convert Barcode_NA to NA if transition cutoff used
    if (is.data.frame(transition_cutoff)) {
        return[grepl("NA_", Barcode, fixed = TRUE), Barcode := NA]
    }

    return(list(
        return = return,
        feature_log = feature_log))
}

