#' multiple_assignments
#'
#' @description Estimates the number of multiple assignments per transition.
#'
#' @usage
#' multiple_assignments(
#'     assignments)
#' @param assignments Data table of assignments from |utility_tr|
#'
#' @format \tabular{lll}{
#' assignments \tab \tab Data table. \cr
#' }
#'
#' @return
#' Matrix listing the number of isobars per transition.
#'
#' @keywords internal

multiple_assignments <- function(assignments) {

    ## Null strategy to pass R CMD check
    Num_assign <- Posterior <- Guaranteed <- Barcode <- Barcode_true <- NULL

    ## No referencing
    assignments <- copy(assignments)

    ## Remove any NA assignments because they inflate the multiple assignments
    assignments <- assignments[!(is.na(Barcode))]

    assignments[, "Num_assign" := .N, by = c("Index", "Sample.Name")]
    multiple_table <- matrix(
        NA,
        ncol = 4,
        nrow = length(assignments[, unique(Num_assign)]),
        dimnames = list(
            c(),
            c(
                "No. candidate assignments",
                "Detected peaks",
                "Not detected peaks",
                "Guaranteed assignments")))

    ## Fill table
    for (kRow in seq_along(assignments[, unique(Num_assign)])) {
        multiple_table[kRow, 1] <- assignments[, unique(Num_assign)[kRow]]
        multiple_table[kRow, 2] <- nrow(assignments[
            !(is.na(Posterior)) & Num_assign == unique(Num_assign)[kRow]])
        multiple_table[kRow, 3] <- nrow(assignments[
            is.na(Posterior) & Num_assign == unique(Num_assign)[kRow]])

        assignments[
            Num_assign == unique(Num_assign)[kRow] &
                !(is.na(Posterior)) &
                Posterior > 0
            , "Guaranteed" := ifelse(.N == 1, TRUE, FALSE)
            , by = c("Index", "Sample.Name")]
        assignments[
            Num_assign == unique(Num_assign)[kRow] &
                Guaranteed == TRUE &
                Barcode == Barcode_true
            , Guaranteed := TRUE]
        multiple_table[kRow, 4] <- nrow(assignments[
            Num_assign == unique(Num_assign)[kRow] & Guaranteed == TRUE])
    }
    assignments[, c("Num_assign", "Guaranteed") := NULL]

    multiple_table <- multiple_table[order(multiple_table[, 1]), ]
    return(multiple_table)
}
