#' deartifact_export_peaks
#'
#' @description Wrapper function to export a peak file from
#' \emph{deartifact_peaks}.
#'
#' @usage
#' deartifact_export_peaks(file, filename)
#'
#' @param file Data table of peak file with the Insource_annotation column.
#' @param filename Name and path of output text file (ending in *.txt)
#'
#' @details
#' \tabular{lll}{
#' file \tab \tab Data.table \cr
#' filename \tab \tab String. \cr
#' }
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette
#' }
#'
#' @export deartifact_export_peaks
#'

deartifact_export_peaks <- function(file, filename) {
    if (!(is.data.frame(file))) {
        stop("file must be a data.frame/data.table object.")
    }
    if (!(is.character(filename))) {
        stop("filename must be a string.")
    }
    if (grepl(".txt$", filename) == FALSE) {
        stop("filename must end with a '.txt' extension.")
    }

    file <- as.data.table(file)
    fwrite(
        x = file,
        file = filename,
        sep = "\t",
        row.names = FALSE,
        col.names = TRUE)
}
