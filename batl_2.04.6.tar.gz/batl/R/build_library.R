#' build_library
#'
#' @description Creates a minimal library of barcoded lipid species using a
#' master Excel spreadsheet, vector of qsession files, and optional Excel
#' spreadsheet of biological matrix information.
#'
#' @usage
#' build_library(
#'     qsession,
#'     training,
#'     training_info,
#'     ...)
#'
#' @param training Path referencing a master Excel spreadsheet.
#' @param qsession Vector of Multiquant qsession file paths.
#' @param training_info Optional path referencing an Excel spreadsheet for
#' matrix information. Default is set to NA.
#' @param ... Optional "mismatch" to find mismatches between master Excel
#' spreadsheet and the Multiquant qsession files. Used for
#' \code{\link{spreadsheet_mismatches}}.
#'
#' @format \tabular{lll}{
#' training \tab \tab  Character string. \cr
#' qsession \tab \tab Character vector. \cr
#' training_info \tab \tab Character string. \cr
#' ... \tab \tab "mismatch" is either TRUE or FALSE.}
#'
#' @return
#' A data.table object is returned from \emph{build_library}. This object
#' contains all of the necessary columns to locate an SRM peak from a qsession,
#' the lipid identity or barcode, and
#' matrix annotation. The column "Filename" is the input path of each qsession
#' file. The columns "Sample.Name", "Index", "Q1", and "Q3" are taken directly
#' directly from the qsession files (Mass Info column in the qsession files are
#' split into Q1 and Q3).
#' The "Barcode" column contains the lipid identity code taken from
#' the input master Excel spreadsheet. The "Matrix" column is set to NA if no
#' training_info is specified. Otherwise, "Matrix" contains the matrix
#' descriptors found in the optional Excel spreadsheet.
#'
#' @examples
#' \dontrun{
#'
#' ## Parameters
#' training <- "/path/.../MasterSphingolipids.xlsx"
#' qsession <- c(
#'     "/path/.../Qsession_file_1.txt",
#'     "/path/.../Qsession_file_2.txt")
#' training_info <- "/path/.../Sample_information.xlsx"
#'
#' ## Build library without specifying matrix information
#' library <- build_library(
#'     training = training,
#'     qsession = qsession,
#'     training_info = NA)
#'
#' ## Build library specifying matrix information
#' library <- batl:::build_library(
#'     training = training,
#'     qsession = qsession,
#'     training_info = training_info)
#' }
#'
#' @importFrom openxlsx read.xlsx
#' @importFrom data.table as.data.table fread := tstrsplit setcolorder melt copy
#'
#' @export build_library

build_library <- function(qsession, training, training_info, ...) {

    ## Hardcoded input column names in qsession
    ## "Composite.Mass.Info" and "Barcode"

    ## Hardcoded input column names in training
    ## column(2)  corresponding to "Sample Index"
    ## column(4)  corresponding to "Sample Name"
    ## column(21) corresponding to "Mass Info"
    ## column(1)  corresponding to "Index"
    ## column(56) corresponding to "Retention Time"

    ## Harcoded input column names in training_info
    ## "Sample Name"
    ## "Matrix"

    ## Null strategy to pass R CMD check
    Q1 <- Q3 <- Sample.Name <- Retention.Time <- Composite.Mass.Info <- NULL
    Qsession <- Mass.Info <- Matrix <- Run <- Barcode <- NULL
    Temp_concat_match <- Remove <- V1 <- Filename <- NULL

    ## Error-checking
    ## If training_info spreadsheet is not specified, set matrix to zero
    if (missing(training_info)) {
        training_info <- NA
    } else if (
        is.character(training_info) == FALSE & length(training_info) != 1) {
        stop("training_info must be a string of length 1.")
    }

    ## Capture unevaluated expressions
    params <- list(...)
    if ("mismatch" %in% names(params)) {
        mismatch <- params[[which(names(params) %in% "mismatch")]]
    } else {
        mismatch <- FALSE
    }

    ## Load training dataset columns of interest
    ## HARDCODED FOR PERSONAL LIBRARY
    col_index <- read.xlsx(
        training,
        rows = seq_len(2),
        skipEmptyCols = FALSE,
        skipEmptyRows = FALSE)
    col_index <- t(col_index)
    col_index <- as.numeric(unlist(which(col_index[, 1] == 1)))

    ## Load subset of training data
    dataset <- read.xlsx(
        training,
        skipEmptyCols = FALSE,
        skipEmptyRows = FALSE,
        cols = col_index)
    dataset <- as.data.table(dataset)

    ## Remove any placeholder rows with invalid Composite mass info values
    while (length(
        grep("/", dataset[1, Composite.Mass.Info], fixed = TRUE)) == 0) {
        dataset <- dataset[-1]
    }

    ## Get sample names of all qsessions
    qsession_run_names <- vector("list", length = length(qsession))
    for (kFile in seq_along(qsession)) {
        qsession_run_names[[kFile]] <- fread(
            qsession[kFile], select = c(4), sep = "\t", header = TRUE)
        qsession_run_names[[kFile]] <- as.vector(
            unlist(unique(qsession_run_names[[kFile]])))
        qsession_run_names[[kFile]] <- gsub(
            "\\s+", ".", qsession_run_names[[kFile]])
        qsession_run_names[[kFile]] <- trimws(qsession_run_names[[kFile]])
    }
    names(qsession_run_names) <- qsession

    ## Unlist sample names, figure out which ones are duplicates, mark with NA
    qsession_unlist <- as.character(unlist(qsession_run_names))
    qsession_unlist[which(duplicated(qsession_unlist))] <- NA

    ## Convert vector back to list with original lengths and remove NA
    col_2 <- cumsum(as.numeric(lengths(qsession_run_names)))
    col_1 <- c(1, (col_2 + 1)[seq_len(length(col_2) - 1)])
    cmat <- as.matrix(cbind(col_1, col_2))
    for (kList in seq_len(length(qsession_run_names))) {
        qsession_run_names[[kList]] <- qsession_unlist[
            cmat[kList, 1]:cmat[kList, 2]]
    }
    qsession_run_names <- lapply(qsession_run_names, function(x) x[!(is.na(x))])

    ## Only keep qsession names shared in training data
    for (kFile in seq_along(qsession_run_names)) {
        for (kRun in seq_along(qsession_run_names[[kFile]])) {
            if (length(which(
                colnames(dataset) %in%
                qsession_run_names[[kFile]][kRun])) == 0) {
                warning(paste0(
                    "Sample ",
                    qsession_run_names[[kFile]][kRun],
                    " in ", names(qsession_run_names)[kFile],
                    " did not map to the training dataset."))
                qsession_run_names[[kFile]][kRun] <- NA
            } else if (length(which(
                colnames(dataset) %in%
                qsession_run_names[[kFile]][kRun])) > 1) {
                stop(paste0(
                    "Sample ",
                    qsession_run_names[[kFile]][kRun],
                    " matched multiple column names in the training",
                    " dataset. Ensure that all duplicated names are",
                    " removed. Also ensure "))
            }
        }
    }

    ## Remove duplicated (NA) run names
    qsession_run_names <- lapply(qsession_run_names, function(x) x[!(is.na(x))])

    ## Remove any list elements containing no run names
    qsession_run_names <- qsession_run_names[lengths(qsession_run_names) > 0]

    if (length(qsession_run_names) == 0) {
        stop("No qsession samples matched to the spreadsheet library.")
    }

    ## Load all qsession files and only keep unique and shared sample runs
    qsession_concat <- vector("list", length = length(qsession_run_names))
    for (kFile in seq_along(qsession_run_names)) {
        qsession_concat[[kFile]] <- fread(
            names(qsession_run_names)[kFile],
            sep = "\t",
            header = TRUE,
            na.strings = "N/A",
            select = c(2, 4, 21, 1, 56))
        colnames(qsession_concat[[kFile]]) <- gsub(
            "\\s+",
            ".",
            colnames(qsession_concat[[kFile]]))
        qsession_concat[[kFile]][
            , "Filename" := names(qsession_run_names)[kFile]]
        qsession_concat[[kFile]][
            , Filename := gsub("\\s+", ".", Filename)]
        qsession_concat[[kFile]][, Filename := trimws(Filename)]
        qsession_concat[[kFile]][
            , Sample.Name := gsub("\\s+", ".", Sample.Name)]
        qsession_concat[[kFile]][, Sample.Name := trimws(Sample.Name)]
        qsession_concat[[kFile]] <- qsession_concat[[kFile]][
            Sample.Name %in% qsession_concat[[kFile]][
                , unique(Sample.Name)[(qsession_concat[[kFile]][
                    , unique(Sample.Name)] %in% qsession_run_names[[kFile]])]]]
    }

    ## Concatenate list of qsessions together and split mass info
    qsession_concat <- do.call("rbind", qsession_concat)
    qsession_concat[
        , c("Q1", "Q3") := tstrsplit(gsub("\\s+", "", Mass.Info), "/")]
    qsession_concat[, Q1 := as.character(Q1)]
    qsession_concat[, Q3 := as.character(Q3)]
    qsession_concat[, "Mass.Info" := NULL]

    ## Enforce strict rounding rule. Truncate to 7 decimals, convert to numeric,
    ## potentially lose trailing zeros, then round to two decimal places,
    ## and convert back to character
    suppressWarnings(qsession_concat[, Retention.Time := as.character(
        round(as.numeric(sprintf("%.7f", Retention.Time)), 2))])

    ## Add matrix information from training information column
    if (!(is.na(training_info))) {
        training_info <- read.xlsx(xlsxFile = training_info)
        training_info <- as.data.table(training_info)
        colnames(training_info) <- gsub("\\s+", ".", colnames(training_info))
        colnames(training_info) <- trimws(colnames(training_info))
        training_info[, Sample.Name := gsub("\\s+", ".", Sample.Name)]
        training_info[, Sample.Name := trimws(Sample.Name)]
        qsession_concat[
            , "Matrix" := training_info[, Matrix][
                match(qsession_concat[
                    , Sample.Name], training_info[
                        , Sample.Name])]]
    } else {
        qsession_concat[, "Matrix" := NA]
    }

    ## Only keep columns in training dataset matching qsession_concat
    run_start <- grep("MolecularID", colnames(dataset)) + 1
    dataset_end <- grep("MolecularID", colnames(dataset))
    run_index <- which(colnames(dataset)[
        seq(run_start, ncol(dataset), by = 1)] %in% qsession_concat[
            , unique(Sample.Name)]) + dataset_end
    dataset <- dataset[, c(seq_len(dataset_end), run_index), with = FALSE]

    ## Split training mass info
    dataset[
        , c("Q1", "Q3") := tstrsplit(
            gsub("\\s+", "", Composite.Mass.Info), "/")]
    dataset[, Q1 := as.character(Q1)]
    dataset[, Q3 := as.character(Q3)]
    dataset[, Composite.Mass.Info := NULL]
    setcolorder(
        dataset, c(
            seq((ncol(dataset) - 1), (ncol(dataset)), by = 1),
            seq_len(ncol(dataset) - 2)))

    ## Coerce each sample column of retention times to numeric
    for (iCol in (grep("MolecularID", colnames(dataset)) + 1):ncol(dataset)) {
        set(dataset, j = iCol, value = as.numeric(dataset[[iCol]]))
    }

    ## Melt training dataset
    dataset <- melt(dataset,
                    measure.vars = (grep(
                        "MolecularID", colnames(dataset)) + 1):ncol(dataset),
                    variable.name = "Run", value.name = "Retention.Time")

    ## Enforce strict rounding rule. Truncate to 7 decimals, convert to numeric,
    ## potentially lose trailing zeros, then round to two decimal places,
    ## and convert back to character
    dataset[, Retention.Time := as.numeric(Retention.Time)]
    suppressWarnings(dataset[, Retention.Time := as.character(
        round(as.numeric(sprintf("%.7f", Retention.Time)), 2))])

    ## Map barcodes in the training dataset to qsession_cocat
    qsession_concat[, "Barcode" := NA_character_]
    qsession_concat[, "Temp_concat_match" := paste(
        Q1, Q3, Retention.Time
        , sep = "_")]
    dataset[
        , "Temp_concat_match" := paste(
            Q1, Q3, Retention.Time
            , sep = "_")]
    if (any(!(dataset[, unique(Run)] %in% qsession_concat[, Sample.Name]))) {
        stop(paste0(
            "Code needs to be fixed. Sample runs aren't consistent ",
            "between dataset and qsessions"))
    }

    ## Remove sample run if all 'Retention.Time' are NA
    dataset[
        , "Remove" := ifelse(all(is.na(Retention.Time)), TRUE, FALSE)
        , by = "Run"]
    dataset <- dataset[Remove == FALSE]
    dataset[, "Remove" := NULL]

    ## Initialize return table of leftover library entries
    return_mismatch_lib <- copy(dataset)
    return_mismatch_lib <- return_mismatch_lib[0]
    return_mismatch_qfile <- copy(qsession_concat)
    return_mismatch_qfile <- return_mismatch_qfile[0]

    ## Assign library barcodes to qsession based on Q1/Q3/RT
    ## Matching qsession to library; NA barcode means a failed match
    for (kRun in seq_along(qsession_concat[, unique(Sample.Name)])) {

        ## Current run
        shared_run <- qsession_concat[, unique(Sample.Name)[kRun]]

        ## Assigning barcodes
        barcodes <- dataset[, Barcode][
            match(qsession_concat[
                Sample.Name == shared_run, Temp_concat_match]
                , dataset[Run == shared_run, Temp_concat_match])]
        qsession_concat[
            Sample.Name == unique(Sample.Name)[kRun]
            , Barcode := barcodes]

        if (mismatch == TRUE) {
            ## Are there any qsession peaks that don't match to the library
            return_mismatch_qfile <- rbind(
                return_mismatch_qfile,
                qsession_concat[
                    Sample.Name == shared_run & !(is.na(Retention.Time))][
                    which(is.na(match(qsession_concat[
                        Sample.Name == shared_run & !(is.na(Retention.Time))
                        , Temp_concat_match]
                        , dataset[Run == shared_run, Temp_concat_match])
                    ))
                ]
            )

            ## Are there any "leftover" library entries that don't match the
            ## qsession?
            return_mismatch_lib <- rbind(
                return_mismatch_lib,
                dataset[Run == shared_run & !(is.na(Retention.Time))][
                    which(is.na(match(dataset[
                        Run == shared_run & !(is.na(Retention.Time))
                        , Temp_concat_match]
                        , qsession_concat[
                            Sample.Name == shared_run & !(is.na(Retention.Time))
                            , Temp_concat_match])))])
        }
    }

    ## Remove sample run if all barcodes are NA
    qsession_concat[
        , "Remove" := ifelse(all(is.na(Barcode)), TRUE, FALSE)
        , by = c("Filename", "Sample.Name", "Index")]
    if (any(
        qsession_concat[, all(Remove == TRUE), by = "Sample.Name"][
            , V1] == TRUE)) {
        warn_names <- qsession_concat[
            , all(Remove == TRUE)
            , by = "Sample.Name"][V1 == TRUE, unique(Sample.Name)]
        warning(paste0(
            "The following sample runs contained NO matching barcodes to the ",
            "input library: ",
            paste0(warn_names, collapse = "\n")
        ))
        qsession_concat <- qsession_concat[!(Sample.Name %in% warn_names)]
    }
    qsession_concat[, "Remove" := NULL]

    if (mismatch == FALSE) {
        ## Remove temporary columns and reorder
        qsession_concat[, c("Retention.Time", "Temp_concat_match") := NULL]
        setcolorder(qsession_concat, c(4, 1, 2, 3, 5, 6, 8, 9, 7))

        ## Final check
        if (length(
            which(
                duplicated(
                    qsession_concat,
                    by = c(
                        "Filename",
                        "Sample.Index",
                        "Sample.Name",
                        "Index")))) > 0) {
            stop(
                paste0(
                    "Duplicated peak indices within the same Qsession",
                    "file, sample index, and sample name"))
        }
        return(qsession_concat)

    } else if (mismatch == TRUE) {
        ## Only remove one column
        qsession_concat[, "Temp_concat_match" := NULL]
        setcolorder(qsession_concat, c(4, 1, 2, 5, 6, 8, 9, 7, 3))
        return(list(
            library = qsession_concat,
            mismatch_lib = return_mismatch_lib,
            mismatch_qsession = return_mismatch_qfile))
    }
}
